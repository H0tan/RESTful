# WME-Project

Aufgabe1

Team 14: Wilhelm Schacht (s1474875) and Alexander Kretzschmar (s3252280) 